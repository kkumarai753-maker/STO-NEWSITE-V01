import Link from "next/link";
import { Globe, LifeBuoy, TrendingUp, Workflow } from "lucide-react";
import { Button, ButtonArrow } from "@/components/ui/button";
import { siteConfig } from "@/config/site";
import { HomeSlider } from "@/components/slider/home-slider";
import { HeroCrystal } from "./hero-crystal";
import { HeroDemo } from "./hero-demo";

/**
 * Home hero (Server Component). Two columns: a descriptive h1 set as the
 * kicker (what we do, where), the display slogan, the promise and actions on
 * the left; the floating glass crystal on the right (desktop only). Right
 * under the copy, the service banner slider (client island), then the
 * four-part index as glass tiles beside the live workflow example. The
 * slogan is visible on first paint (no entrance animation) to protect LCP.
 */
const PILLARS = [
  { label: "Web", desc: "Fast, responsive digital experiences", icon: Globe },
  { label: "Growth", desc: "Content, campaigns and leads", icon: TrendingUp },
  { label: "Automation", desc: "Connected customer workflows", icon: Workflow },
  { label: "Support", desc: "Direct and practical assistance", icon: LifeBuoy },
];

export function Hero() {
  const city = siteConfig.contact.location.split(",").slice(-3, -2)[0]?.trim();

  return (
    <section
      aria-labelledby="hero-title"
      className="theme-glow relative isolate overflow-hidden pt-[calc(var(--nav-height)+clamp(2rem,1rem+4vw,4.5rem))] pb-[clamp(4rem,2.8rem+4vw,6.25rem)]"
    >
      <div className="container-page relative z-1">
        <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-6">
            <h1 id="hero-title" className="hero-enter inline-flex items-center gap-2.5 label-mono text-accent">
              <span aria-hidden className="size-1.5 shrink-0 rounded-full bg-accent shadow-[0_0_0_4px_color-mix(in_oklab,var(--accent)_18%,transparent)]" />
              <span>Websites, AI automation and digital marketing{city ? ` in ${city}` : ""}</span>
            </h1>

            <p className="mt-6 font-display text-display-1 text-balance text-text [font-family:var(--ff-heading)]">
              <span className="block">Build smarter.</span>
              <span className="block">
                <em>Grow digitally.</em>
              </span>
              <span className="block">Operate better.</span>
            </p>

            <p
              className="hero-enter mt-6 max-w-[520px] text-lead text-text-muted"
              style={{ "--enter-delay": "120ms" } as React.CSSProperties}
            >
              One practical partner for websites and apps, AI integration and automation, business
              software, digital marketing and lead generation, built for startups and growing businesses.
            </p>

            <div
              className="hero-enter mt-9 flex flex-col gap-3 sm:flex-row sm:items-center"
              style={{ "--enter-delay": "220ms" } as React.CSSProperties}
            >
              <Button asChild size="lg" magnetic>
                <Link href="/services">
                  Explore Services
                  <ButtonArrow />
                </Link>
              </Button>
              <Button asChild size="lg" variant="secondary">
                <Link href="/inquiry">Book a Free Consultation</Link>
              </Button>
            </div>
          </div>

          {/* Decorative: on phones the service slider follows the text instead. */}
          <div
            className="hero-enter hidden w-full lg:col-span-6 lg:block lg:justify-self-end lg:max-w-[33rem]"
            style={{ "--enter-delay": "160ms" } as React.CSSProperties}
          >
            <HeroCrystal />
          </div>
        </div>

        <HomeSlider className="hero-enter mt-10 lg:mt-12" />

        <div className="mt-12 grid gap-6 lg:mt-16 lg:grid-cols-12 lg:items-stretch lg:gap-8">
          <ul aria-label="What we cover" className="grid grid-cols-2 gap-4 sm:gap-5 lg:col-span-7">
            {PILLARS.map((item, i) => (
              <li
                key={item.label}
                data-reveal=""
                style={{ "--reveal-delay": `${i * 70}ms` } as React.CSSProperties}
                className="glass-card glass-hover flex flex-col gap-2 rounded-[1.25rem] p-5 sm:p-6"
              >
                <span className="mb-auto flex items-start justify-between gap-3 pb-6">
                  <span aria-hidden className="icon-tile size-11 sm:size-12">
                    <item.icon className="size-5" strokeWidth={1.75} />
                  </span>
                  <span className="label-mono text-faint numeric">{String(i + 1).padStart(2, "0")}</span>
                </span>
                <strong className="font-display text-[1.375rem] leading-none text-text sm:text-[1.625rem]">
                  {item.label}
                </strong>
                <span className="text-sm leading-snug text-text-muted">{item.desc}</span>
              </li>
            ))}
          </ul>

          <div className="min-w-0 lg:col-span-5" data-reveal="" style={{ "--reveal-delay": "120ms" } as React.CSSProperties}>
            <HeroDemo className="h-full" />
          </div>
        </div>
      </div>
    </section>
  );
}
