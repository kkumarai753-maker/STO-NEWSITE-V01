import { WhyUsSection } from "@/components/about/why-us-section";
// Hidden for now, uncomment (here and below) to bring the sections back.
// import { AutomationSection } from "@/components/ai-automation/automation-section";
// import { CaseStudiesSection } from "@/components/case-studies/case-studies-section";
import { ContactSection } from "@/components/contact/contact-section";
import { FaqSection } from "@/components/faq/faq-section";
import { FilmSection } from "@/components/process/film-section";
import { Hero } from "@/components/hero/hero";
import { ProcessSection } from "@/components/process/process-section";
import { ProductsSection } from "@/components/products/products-section";
import { PageSchema } from "@/components/seo/json-ld";
import { DivisionsSection } from "@/components/divisions/divisions-section";
import { ServicesSection } from "@/components/services/services-section";
// import { TechMarquee } from "@/components/technology/tech-marquee";
import { TestimonialsSection } from "@/components/testimonials/testimonials-section";
import { pageMetadata } from "@/lib/seo";

// The root opengraph-image.tsx already supplies this page's social card.
export const metadata = pageMetadata("/", { ownImage: true });

/** The contact form's Server Action saves via the backend, which may need time to wake from sleep. */
export const maxDuration = 60;

/**
 * Home page, a Server Component composed of server-rendered sections.
 * Interactive pieces are small client islands inside each section.
 */
export default function HomePage() {
  return (
    <>
      <PageSchema path="/" />
      <Hero />
      <DivisionsSection />
      {/* <TechMarquee /> */}
      <ServicesSection />
      {/* <AutomationSection /> */}
      <ProductsSection />
      {/* <CaseStudiesSection /> */}
      <FilmSection />
      <ProcessSection />
      <WhyUsSection />
      <TestimonialsSection />
      <FaqSection />
      <ContactSection />
    </>
  );
}
